# Lab 14 — microRAG (guided walkthrough)

DS 6042 · Module 5 · ~2 hours in class + 2-hour assignment.

The smallest readable Retrieval-Augmented Generation pipeline. Two
retrievers (TF-IDF + hashed-feature embeddings), one hybrid scorer,
one prompt assembler, one LLM call. Read top to bottom in ~200 lines.

## Files

```
lab-14/
├── microrag.html                  ← walkthrough page (student-facing)
├── styles.css, viz.js
├── README.md
│
├── rag/
│   └── micro_rag.py               ← the entire pipeline (~200 lines)
├── microdata/
│   ├── password_policy.md         ← four-document knowledge base
│   ├── network_help.md
│   ├── onboarding.md
│   └── architecture.md
└── solution/
    └── NOTES.md                   ← instructor notes
```

## Run it

```bash
cd Class/labs/lab-14

# retrieval only — no LLM needed
python rag/micro_rag.py retrieve "how do I reset my password?"

# full RAG round-trip (set Rivanna creds first)
export LLM_BASE_URL=https://api.research-computing.virginia.edu/v1
export LLM_API_KEY=...
export LLM_MODEL=moonshotai/kimi-k2-instruct
python rag/micro_rag.py ask "how do I reset my password?"
```

Stdlib only for the retrieval path; needs `httpx` for the LLM call
(`pip install httpx`). For real semantic embeddings, also install
`sentence-transformers` — the file's optional-import block picks it up
automatically.

## Next lab

[Lab 15 · Attacking RAG](../lab-15/attack-rag.html) — five canonical
attacks against a server structurally identical to microRAG, including
the OffSec AI-300 §5 ingestion poisoning, embedding collision,
retrieval hijacking, and filter-bypass walkthroughs.
