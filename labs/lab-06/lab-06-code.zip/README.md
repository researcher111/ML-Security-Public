# Lab 06 — microMCP (guided walkthrough)

DS 6042 · Module 4 (security against ML systems) · ~2 hours in class
plus a 2-hour assignment.

The MCP half of the "smallest readable" family. Lab 02 stripped a
transformer to one layer; Lab 04 stripped an agent to one tool; Lab 06
strips a Model Context Protocol server to two tools and one transport.
By the end of the lab you have read every line of an MCP server and an
MCP client.

## Files

```
lab-06/
├── micromcp.html                ← main walkthrough page
├── styles.css
├── viz.js                       ← interactive JSON-RPC trace stepper
├── README.md                    ← this file
│
├── server/
│   └── micromcp.py              ← the smallest readable MCP server (~140 lines)
├── client/
│   └── microclient.py           ← spawn the server, send JSON-RPC, print replies
├── microdata/
│   ├── hello.md                 ← three tiny markdown files the
│   ├── password_policy.md         read_file tool can reach
│   └── network_help.md
│
└── solution/
    └── NOTES.md                 ← instructor notes
```

## Run it

```bash
cd Class/labs/lab-06

# interactive REPL
python client/microclient.py

# one-shot
python client/microclient.py list
python client/microclient.py call read_file path=hello.md
python client/microclient.py call get_greeting name=alice
```

No third-party packages. Python 3.10+ stdlib only.

## Open the walkthrough

`micromcp.html` opens directly in a browser. No server required.

## Next lab

[Lab 07 · Attacking MCP](../lab-07/attack-mcp.html) takes a production-shape
MCP server and runs five canonical attacks against it — description
poisoning, path traversal (CVE-2025-53109/53110), over-privileged tool,
MCP Apps UI poisoning, and Jinja2 SSTI through a three-tool chain.
