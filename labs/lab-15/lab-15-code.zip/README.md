# Lab 15 — Attacking RAG

DS 6042 · Module 5 · ~2.5 hours in class + 3-hour assignment.

Five canonical attacks against a production-shape RAG server that's
structurally identical to Lab 14 microRAG. Each attack maps to a MITRE
ATLAS technique and lands on an explicit `# Vuln N` block in
`server/baseline_rag.py`.

| # | Attack                    | MITRE ATLAS         | Vuln location                          |
|---|---------------------------|---------------------|----------------------------------------|
| 1 | Knowledge-base leakage    | T0024               | `seed_from_disk()` + `data/it_inventory.md` |
| 2 | Ingestion poisoning       | T0020               | `/ingest` endpoint                     |
| 3 | Embedding collision       | T0020 + T0043       | `retrieve(w_kw=0.6)`                   |
| 4 | Retrieval hijacking       | T0051.001           | `file_read()` tool + sys prompt        |
| 5 | Filter bypass via encoding| T0054               | `input_guard()` + `output_guard()`     |

## Files

```
lab-15/
├── attack-rag.html                  ← walkthrough page (student-facing)
├── styles.css, viz.js
├── README.md
│
├── server/
│   ├── baseline_rag.py              ← FastAPI server, 5 planted vulns
│   └── requirements.txt
├── data/
│   ├── it_inventory.md              ← planted secrets (svc passwords, API keys)
│   ├── contact_list.md              ← planted PII (employee emails)
│   ├── password_policy.md
│   └── network_help.md
├── attacks/
│   ├── _helpers.py                  ← shared client / pretty-print
│   ├── 01_kb_leakage.py
│   ├── 02_ingestion_poisoning.py
│   ├── 03_embedding_collision.py
│   ├── 04_retrieval_hijacking.py
│   └── 05_filter_bypass.py
└── solution/
    └── NOTES.md                     ← instructor notes
```

## Run it

```bash
cd Class/labs/lab-15
python3 -m venv .venv && source .venv/bin/activate
pip install -r server/requirements.txt

export LLM_BASE_URL=https://api.research-computing.virginia.edu/v1
export LLM_API_KEY=...
export LLM_MODEL="Kimi K2.5"

uvicorn server.baseline_rag:app --port 8090 --reload &
python attacks/01_kb_leakage.py
python attacks/02_ingestion_poisoning.py
python attacks/03_embedding_collision.py
python attacks/04_retrieval_hijacking.py
python attacks/05_filter_bypass.py
```

Each script exits 0 on success and prints the attack's stage-by-stage
output. Scripts 02 and 03 reset the server before/after to keep runs
idempotent.

## Authorized use

These attacks run **only against a server you started yourself**. The
"MegaCorpAI" data is fake; the credentials are planted for the exercise.
Don't run any of this against a RAG system you don't own. See the
"Authorized use" callout in `attack-rag.html` for the full boundary.

## Previous lab

[Lab 14 · microRAG](../lab-14/microrag.html) — the smallest readable
build of the same pipeline. Read it first; the attacks here line up
with the hint callouts there.
