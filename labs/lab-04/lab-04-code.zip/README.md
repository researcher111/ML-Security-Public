# Lab 04 — microagent (guided walkthrough)

DS 6042 · Module 4 · ~2 hours in class + 2-hour assignment.

The agent half of Lab 02. Stripped down to one tool, one loop, one
file — every line readable on one screen. Then scaled up to the
production-shape agent students will attack in Lab 05.

## Files

```
lab-04/
├── microagent.html              ← main walkthrough page (student-facing)
├── styles.css
├── viz.js                       ← interactive ReAct trace widget +
│                                  hover-per-line annotated code blocks
├── README.md                    ← this file
│
├── agent/
│   ├── microagent.py            ← the small script (< 100 lines), file_read only
│   └── microdata/               ← three tiny markdown files for the
│       ├── password_policy.md     agent's one tool to read
│       ├── network_help.md
│       └── hello.md
│
├── assignment/                  ← the autograded deliverable (run_command tool)
│   ├── microagent.py            ← template: four TODOs (allowlist + safety + tool)
│   ├── test_microagent.py       ← local sanity tests
│   ├── .env.example             ← LLM_* template (cp to .env for --real)
│   ├── microdata/  sandbox/      ← data the tools read / run inside
│   └── autograder/              ← Gradescope bundle (grader.py, run_autograder, …)
│       └── build_zip.sh         ← → autograder.zip
│
└── solution/
    ├── microagent.py            ← reference solution (run_command + is_safe_command)
    ├── microdata/  sandbox/
    └── NOTES.md                 ← instructor notes
```

## Run it

```bash
cd Class/labs/lab-04

# Toy mode — no API, hand-traceable.
python agent/microagent.py --toy

# Real mode — needs Rivanna GenAI env vars.
export LLM_BASE_URL=https://api.research-computing.virginia.edu/v1
export LLM_API_KEY=...
export LLM_MODEL=moonshotai/kimi-k2-instruct
python agent/microagent.py --real
```

## Open the walkthrough

Just open `microagent.html` in a browser. No server required.

## Assignment (autograded)

Students give the agent a `run_command` tool gated two ways — an **allowlist**
that auto-rejects dangerous commands and a **human-in-the-loop confirmation**
prompt — then submit `assignment/microagent.py` to Gradescope.

The whole lab (toy, `--real`, and the assignment) is run inside a **Rivanna
interactive Code Server session** — the RC GenAI / Kimi endpoint is reachable
from there directly (no tunnel). The command tool is kept safe by the allowlist
plus the per-command confirmation, not by sandbox isolation.

```bash
cd assignment
python microagent.py --toy        # run YOUR scenario
python test_microagent.py         # local checks before submitting

cd autograder
./build_zip.sh                     # -> autograder.zip for Gradescope
python3 grader.py --submission ../../solution   # reference -> 100/100
```

Students can also `curl` the template into their Rivanna session from the
GitHub Pages deploy (`https://researcher111.github.io/ML-Security-Public/labs/lab-04/assignment/…`)
— the lab page's "Get the code" block has the commands.

## Next lab

Lab 05 (`../lab-05/attack-agents.html`) attacks an agent line-for-line
identical in shape to `microagent.py`'s "scaled up" cousin
(`../lab-05/agent/baseline_agent.py`).
