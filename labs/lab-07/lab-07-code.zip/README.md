# Lab 10 — Attacking MCP

DS 6042 · Module 4 · ~3 hours in class + 3-hour assignment.

Five canonical attacks on a production-shape MCP server. The server is
structurally a microMCP (see [Lab 09](../lab-09/micromcp.html)) — same
JSON-RPC, same tool catalog — but with seven tools instead of two,
HTTP transport instead of stdio, and four planted vulnerabilities
matching the OffSec AI-300 §7 syllabus and the relevant MITRE ATLAS
techniques.

## Files

```
lab-10-attack-mcp/
├── attack-mcp.html               ← main lab page (student-facing)
├── styles.css
├── viz.js
├── README.md                     ← this file
│
├── server/
│   ├── baseline_server.py        ← vulnerable server, run on port 8080
│   ├── secure_server.py          ← hardened twin, run on port 8081
│   ├── init_db.py                ← seed data/megacorp.db (run once)
│   ├── requirements.txt
│   └── tool_descriptions/
│       └── format_code.txt       ← the poisonable description (Attack 1)
│
├── data/
│   ├── documents/                ← legitimate sandbox content
│   ├── .secrets/credentials.json ← path-traversal target (Attack 2)
│   └── megacorp.db               ← populated by init_db.py
│
├── attacks/
│   ├── _helpers.py
│   ├── 01_description_poisoning.py
│   ├── 02_path_traversal.py
│   ├── 03_over_privileged.py
│   ├── 04_apps_ui_poisoning.py   ← narrative (requires real MCP host)
│   └── 05_tool_chaining_ssti.py
│
└── solution/
    └── NOTES.md                  ← instructor notes
```

## Quick start

```bash
cd Class/labs/lab-10
python3 -m venv .venv && source .venv/bin/activate
pip install -r server/requirements.txt
python server/init_db.py            # one time
uvicorn server.baseline_server:app --port 8080 --reload

# in another terminal:
python attacks/02_path_traversal.py
python attacks/03_over_privileged.py
python attacks/05_tool_chaining_ssti.py
```

For the secure phase:
```bash
uvicorn server.secure_server:app --port 8081 --reload
# edit attacks/_helpers.py: SERVER = "http://127.0.0.1:8081"
# re-run each attack; each should fail
```

## Open the lab page

`attack-mcp.html` opens directly in a browser. No server required for
the page itself; the attacks need a running server.

## MITRE ATLAS coverage

- **T0010.005** AI Supply Chain Compromise · Attack 1 (description poisoning)
- **T0051.001** LLM Prompt Injection: Indirect · Attack 1 + Attack 4
- **T0085** Data from AI Services · Attack 3 (over-privileged DB)
- **T1059** Command and Scripting Interpreter (ATT&CK) · Attack 5 (SSTI → RCE)

## Related CVEs

- [CVE-2025-53109](https://nvd.nist.gov/vuln/detail/CVE-2025-53109) — path traversal in Anthropic's filesystem MCP server
- [CVE-2025-53110](https://nvd.nist.gov/vuln/detail/CVE-2025-53110) — companion sandbox-escape via symlinks
